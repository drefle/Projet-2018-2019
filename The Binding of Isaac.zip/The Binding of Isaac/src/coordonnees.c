#include "tout.h"

/**
* \file coordonnees.c
* \author Adrien P. - Paul PDC. - David C. - Paul C.
* \date 16/04/2019
* \brief Permet l'ajout et la suppression de coordonnées
*/

/*Créer une structure de coordonnées qui est utilisé lors de la génération de la map*/


extern
t_coord * creer_coord(int absi, int ord){
  t_coord * pt;
  pt = malloc(sizeof(t_coord));
  pt->absi = absi;
  pt->ord = ord;
  return pt;
}


/*Fonction de suppression de coordonnées et sa fonction callback*/

static
void supprimer_coord(t_coord * a){
  free(a);
}

extern
void supprimer_coord_cb(void * a){
  supprimer_coord(a);
}
