#include "tout.h"

/**
* \file jeu.c
* \author Adrien P. - Paul PDC. - David C. - Paul C.
* \date 16/04/2019 
* \brief Fonctions principales du jeu, et des menus
*/

extern int nb_mob_tot;
extern int x_salle_finale, y_salle_finale;



int fin(t_joueur * joueur){
  //Le pointeur vers la fenetre
	SDL_Window* pWindow = NULL;

	SDL_Renderer *renderer=NULL;

	SDL_Rect imgvicRect;
	SDL_Rect imgdefRect;

  /* Initialisation simple */
  SDL_Init(SDL_INIT_VIDEO);

	/* Initialisation TTF */
	TTF_Init();

	/* Création de la fenêtre */
	pWindow = SDL_CreateWindow("The Binding of Isaac REMASTERED",SDL_WINDOWPOS_UNDEFINED,SDL_WINDOWPOS_UNDEFINED,1080,650,SDL_WINDOW_SHOWN|SDL_WINDOW_RESIZABLE);

	renderer = SDL_CreateRenderer(pWindow, -1, SDL_RENDERER_ACCELERATED);

	//Chargement victoire
	SDL_Texture *image_victoire_tex = tex_img_png("./img/victoire.png",renderer);
	//Chargement defaite
	SDL_Texture *image_defaite_tex = tex_img_png("./img/defaite.png",renderer);


	if( pWindow )
	{
		int running = 1;
		while(running) {
			SDL_Event e;
			while(SDL_PollEvent(&e)) {
				switch(e.type) {
					case SDL_QUIT: running = 0; break;
					case SDL_KEYDOWN:
					switch(e.key.keysym.sym){
					  case SDLK_ESCAPE: running = 0; break;
					}
				break;
				}
			}
			if( joueur->pv > 0 && joueur->victoire == 1){
				//BACKGROUND2
				imgvicRect.x = 0;
				imgvicRect.y = 0;
				SDL_QueryTexture(image_victoire_tex, NULL, NULL, &(imgvicRect.w), &(imgvicRect.h));
				SDL_RenderCopy(renderer, image_victoire_tex, NULL, &imgvicRect);
			}
			else{
				//BACKGROUND1
				imgdefRect.x = 0;
				imgdefRect.y = 0;
				SDL_QueryTexture(image_defaite_tex, NULL, NULL, &(imgdefRect.w), &(imgdefRect.h));
				SDL_RenderCopy(renderer, image_defaite_tex, NULL, &imgdefRect);
			}
			/* On fait le rendu ! */
      SDL_RenderPresent(renderer);
		}
	}

	//Destruction de la fenetre
	SDL_DestroyWindow(pWindow);
  SDL_Quit();

  return 0;
}


int jeu(){
	int running =1;
	SDL_Window* pWindow = NULL;
	SDL_Renderer *salle_render=NULL;
	SDL_Keycode touche;
	t_res *ressource = malloc(sizeof(t_res));

	int i = 0, j;
	t_salle * m_map[L][L];
	int m_pattern[4][NB_PATTERN][M][N];
	t_joueur * joueur = creer_joueur(L/2, L/2, M/2, N/2, 5);
	srand(time(NULL));
	pWindow = SDL_CreateWindow("The Binding of Isaac REMASTERED",SDL_WINDOWPOS_UNDEFINED,
																SDL_WINDOWPOS_UNDEFINED,
												 				1728,
												  				972,
												  				SDL_WINDOW_SHOWN|SDL_WINDOW_RESIZABLE);

	salle_render = SDL_CreateRenderer(pWindow, -1, SDL_RENDERER_ACCELERATED);

	initscr();
	cbreak();
	noecho();
	nodelay(stdscr, TRUE);

  init_map( m_map );/*Création de la map*/

	remplir_pattern( m_pattern );/*Lecture du fichier qui contient les différents pattern*/

	genmap(m_map, NB_SALLE);/*Remplissage de la map*/


if(pWindow){
 init_res(ressource,salle_render);
				while( ( joueur->pv > 0 ) && !joueur->victoire && running ){
				SDL_Event e;
				deplacer_projectile( m_map[joueur->x_map][joueur->y_map], joueur, i );
				deplacer_monstre( m_map[joueur->x_map][joueur->y_map], joueur , i );

				/*Affichage de la salle et de la map*/
				afficher_salle( m_map,m_map[joueur->x_map][joueur->y_map]->m_salle,salle_render,ressource,joueur);

				if(joueur->x_map == x_salle_finale && joueur->y_map == y_salle_finale){ /* Si le joueur est dans la salle finale */
						maj_salle_finale(m_map[joueur->x_map][joueur->y_map],i);
				}

				i = (i + 1) % 50000;
				refresh();
				usleep(50000 );
				clear();
				while(SDL_PollEvent(&e)) {
					touche = e.key.keysym.sym;
					if(touche == SDLK_ESCAPE){
						running =0;
					}
					controle_joueur(joueur, m_map,touche);

			}
		}
		/* Liberation mémoire */
		for(i=0;i<L;i++){
	    for(j=0;j<L;j++){
	      if(m_map[i][j] != NULL){

	        en_queue(m_map[i][j]->l_monstre);
	      	while(!liste_vide(m_map[i][j]->l_monstre)){
	      		oter_elt(m_map[i][j]->l_monstre);
	      	}

	        free(m_map[i][j]->l_monstre->drapeau);
	        free(m_map[i][j]->l_monstre);

	        en_queue(m_map[i][j]->l_projectile);
	      	while(!liste_vide(m_map[i][j]->l_projectile)){
	      		oter_elt(m_map[i][j]->l_projectile);
	      	}

	        free(m_map[i][j]->l_projectile->drapeau);
	        free(m_map[i][j]->l_projectile);
	        free(m_map[i][j]);
	      }
	    }
	  }

	}
	SDL_DestroyWindow(pWindow);
	if( joueur->pv > 0 ){
		fin(joueur);
	}
	else{
		fin(joueur);
	}
	free(joueur);
	SDL_Quit();
return 0;
}





int regle(){
	int pos = 1;
    //Le pointeur vers la fenetre
	SDL_Window* pWindow = NULL;
	//Le pointeur vers la surface incluse dans la fenetre
    SDL_Surface *image = NULL;
	SDL_Surface *image_hover = NULL;

	SDL_Surface *regle1 = NULL;
	SDL_Surface *regle2 = NULL;
	SDL_Surface *regle3 = NULL;
	SDL_Surface *regle4 = NULL;

	SDL_Surface *option1 = NULL;
	SDL_Surface *option2 = NULL;

	SDL_Surface *titre1 = NULL;
	SDL_Surface *titre2 = NULL;
	SDL_Surface *titre3 = NULL;
	SDL_Renderer *renderer=NULL;

	SDL_Rect imgbgRect;
	SDL_Rect imgbg2Rect;
	SDL_Rect imgBtnRect;

	SDL_Rect titre1DestRect;
	SDL_Rect titre2DestRect;
	SDL_Rect titre3DestRect;

	SDL_Rect regle1DestRect;
	SDL_Rect regle2DestRect;
	SDL_Rect regle3DestRect;
	SDL_Rect regle4DestRect;

	SDL_Rect opt1DestRect;
	SDL_Rect opt2DestRect;



	// Le pointeur vers les polices
	TTF_Font *police = NULL;
	TTF_Font *police2 = NULL;
	TTF_Font *police3 = NULL;
	//variables de couleurs
	SDL_Color white = {255, 255, 255};
	SDL_Color brown = {145, 55, 0};

    /* Initialisation simple */
	SDL_Init(SDL_INIT_VIDEO);

	/* Initialisation TTF */
	TTF_Init();


	/* Création de la fenêtre */
	pWindow = SDL_CreateWindow("The Biding of Isaac REMASTERED",SDL_WINDOWPOS_UNDEFINED,
																SDL_WINDOWPOS_UNDEFINED,
												 				1080,
												  				850,
												  				SDL_WINDOW_SHOWN|SDL_WINDOW_RESIZABLE);



	renderer = SDL_CreateRenderer(pWindow, -1, SDL_RENDERER_ACCELERATED);

	police = TTF_OpenFont("./ttf/upheavtt.ttf", 40);
	police2 = TTF_OpenFont("ttf/upheavtt.ttf", 30);
	police3 = TTF_OpenFont("ttf/upheavtt.ttf", 150);

	regle1 = TTF_RenderUTF8_Blended(police2, "Conditions de victoire :", brown);
	regle2 = TTF_RenderUTF8_Blended(police2, "- Obtenir la clé", brown);
	regle3 = TTF_RenderUTF8_Blended(police2, "- Tuer tous les monstres", brown);
	regle4 = TTF_RenderUTF8_Blended(police2, "- Franchir le portail", brown);
	
	SDL_Texture *regle1_tex = SDL_CreateTextureFromSurface(renderer, regle1);
	SDL_Texture *regle2_tex = SDL_CreateTextureFromSurface(renderer, regle2);
	SDL_Texture *regle3_tex = SDL_CreateTextureFromSurface(renderer, regle3);
	SDL_Texture *regle4_tex = SDL_CreateTextureFromSurface(renderer, regle4);

	titre1 = TTF_RenderUTF8_Blended(police2, "the binding of", white);
	titre2 = TTF_RenderUTF8_Blended(police3, "ISAAC", white);
	titre3 = TTF_RenderUTF8_Blended(police2, "REMASTERED", white);

	SDL_Texture *titre1_tex = SDL_CreateTextureFromSurface(renderer, titre1);
	SDL_Texture *titre2_tex = SDL_CreateTextureFromSurface(renderer, titre2);
	SDL_Texture *titre3_tex = SDL_CreateTextureFromSurface(renderer, titre3);

	option1 = TTF_RenderUTF8_Blended(police, "JOUER", white);
	option2 = TTF_RenderUTF8_Blended(police, "QUITTER", white);

	SDL_Texture *option1_tex = SDL_CreateTextureFromSurface(renderer, option1);
	SDL_Texture *option2_tex = SDL_CreateTextureFromSurface(renderer, option2);


	SDL_FreeSurface(regle1);
	SDL_FreeSurface(regle2);
	SDL_FreeSurface(regle3);
	SDL_FreeSurface(regle4);

	SDL_FreeSurface(titre1);
	SDL_FreeSurface(titre2);
	SDL_FreeSurface(titre3);

	SDL_FreeSurface(option1);
	SDL_FreeSurface(option2);

	/* Positionnement des titres */
	titre1DestRect.x = 400;
	titre1DestRect.y = 65;

	titre2DestRect.x = 300;
	titre2DestRect.y = 60;

	titre3DestRect.x = 430;
	titre3DestRect.y = 190;

	/* Positionnement des règles */
  regle1DestRect.x = 300;
	regle1DestRect.y = 280;

	regle2DestRect.x = 320;
	regle2DestRect.y = 300;

	regle3DestRect.x = 320;
	regle3DestRect.y = 320;

	regle4DestRect.x = 320;
	regle4DestRect.y = 340;

	/* Positionnement des textes dans les boutons */
  opt1DestRect.x = 470;
	opt1DestRect.y = 460;

	opt2DestRect.x = 450;
	opt2DestRect.y = 550;

	SDL_QueryTexture(regle1_tex, NULL, NULL, &(regle1DestRect.w), &(regle1DestRect.h));
	SDL_QueryTexture(regle2_tex, NULL, NULL, &(regle2DestRect.w), &(regle2DestRect.h));
	SDL_QueryTexture(regle3_tex, NULL, NULL, &(regle3DestRect.w), &(regle3DestRect.h));
	SDL_QueryTexture(regle4_tex, NULL, NULL, &(regle4DestRect.w), &(regle4DestRect.h));

	SDL_QueryTexture(titre1_tex, NULL, NULL, &(titre1DestRect.w), &(titre1DestRect.h));
	SDL_QueryTexture(titre2_tex, NULL, NULL, &(titre2DestRect.w), &(titre2DestRect.h));
	SDL_QueryTexture(titre3_tex, NULL, NULL, &(titre3DestRect.w), &(titre3DestRect.h));

	SDL_QueryTexture(option1_tex, NULL, NULL, &(opt1DestRect.w), &(opt1DestRect.h));
	SDL_QueryTexture(option2_tex, NULL, NULL, &(opt2DestRect.w), &(opt2DestRect.h));


	//Chargement parchemin menu
	SDL_Texture *image_pa_tex = tex_img_png("./img/bgmenu.png",renderer);
	//Chargement parchemin menu
	SDL_Texture *image_parchemin_tex = tex_img_png("./img/fondmenu.png",renderer);
	//Chargement de l'image bouton
  SDL_Texture *image_btn_tex = tex_img_png("./img/btn.png",renderer);
  //Chargement de l'image bouton (utilisé quand la souris passe sur l'image)
	SDL_Texture *image_btnHover_tex = tex_img_png("./img/btnHover.png",renderer);

	SDL_Texture *temp;

	SDL_FreeSurface(image);
	SDL_FreeSurface(image_hover);

	if( pWindow )
	{
		int running = 1;
		while(running) {
			SDL_Event e;
			while(SDL_PollEvent(&e)) {
				switch(e.type) {
					case SDL_QUIT: running = 0; break;
					case SDL_KEYDOWN:
					switch(e.key.keysym.sym){
					  case SDLK_ESCAPE: running = 0; break;
						case SDLK_DOWN:
						if(pos < 2 ){
							pos++;
						}
						else{
							pos=1;
						}break;
						case SDLK_UP:
							if(pos > 1){
								pos--;
							}
							else{
								pos=2;
							}
						break;
						case SDLK_RETURN:
							switch(pos){
								case 1: /* JOUER */
									SDL_DestroyWindow(pWindow);
									jeu();
								break;
								case 2: /* QUITTER */
									running=0;
									break;
							}
						break;
					}
					case SDL_WINDOWEVENT:
						SDL_RenderClear(renderer);
						//BACKGROUND1
						imgbg2Rect.x = 0;
						imgbg2Rect.y = 0;
						SDL_QueryTexture(image_pa_tex, NULL, NULL, &(imgbg2Rect.w), &(imgbg2Rect.h));
						SDL_RenderCopy(renderer, image_pa_tex, NULL, &imgbg2Rect);

						//BACKGROUND2
						imgbgRect.x = 265;
						imgbgRect.y = 10;
						SDL_QueryTexture(image_parchemin_tex, NULL, NULL, &(imgbgRect.w), &(imgbgRect.h));
						SDL_RenderCopy(renderer, image_parchemin_tex, NULL, &imgbgRect);


						SDL_QueryTexture(image_btnHover_tex, NULL, NULL, &(imgBtnRect.w), &(imgBtnRect.h));
						//Positionnement du premier bouton
              imgBtnRect.x = 440;
              imgBtnRect.y = 440;
						if( pos == 1 ){
							temp = image_btnHover_tex;
						}
						else{
							temp = image_btn_tex;
						}
						SDL_RenderCopy(renderer,temp,NULL,&imgBtnRect);

						imgBtnRect.x=440;
						imgBtnRect.y=530;
						if( pos == 2 ){
							temp = image_btnHover_tex;
						}
						else{
							temp = image_btn_tex;
						}
						SDL_RenderCopy(renderer,temp,NULL,&imgBtnRect);

						/* Affichage règles */
						SDL_RenderCopy(renderer, regle1_tex, NULL, &regle1DestRect);
						SDL_RenderCopy(renderer, regle2_tex, NULL, &regle2DestRect);
						SDL_RenderCopy(renderer, regle3_tex, NULL, &regle3DestRect);
						SDL_RenderCopy(renderer, regle4_tex, NULL, &regle4DestRect);

						/* Affichage des titres */
						SDL_RenderCopy(renderer, titre1_tex, NULL, &titre1DestRect);
						SDL_RenderCopy(renderer, titre2_tex, NULL, &titre2DestRect);
						SDL_RenderCopy(renderer, titre3_tex, NULL, &titre3DestRect);

						/* Affichage texte sur boutons */
						SDL_RenderCopy(renderer, option1_tex, NULL, &opt1DestRect);
						SDL_RenderCopy(renderer, option2_tex, NULL, &opt2DestRect);

						/* On fait le rendu ! */
						SDL_RenderPresent(renderer);
					break;
				}
			}
		}
	}
	//Destruction de la fenetre
	SDL_DestroyWindow(pWindow);
	TTF_CloseFont(police); /* Doit être avant TTF_Quit() */
	TTF_Quit();
    SDL_Quit();

    return 0;
}


int main(){
	int pos = 1;
    //Le pointeur vers la fenetre
	SDL_Window* pWindow = NULL;
	//Le pointeur vers la surface incluse dans la fenetre
    SDL_Surface *image = NULL;
	SDL_Surface *image_hover = NULL;

	SDL_Surface *option1 = NULL;
	SDL_Surface *option2 = NULL;
	SDL_Surface *option3 = NULL;

	SDL_Surface *titre1 = NULL;
	SDL_Surface *titre2 = NULL;
	SDL_Surface *titre3 = NULL;
	SDL_Renderer *renderer=NULL;


	SDL_Rect imgBtnRect;
	SDL_Rect imgbgRect;
	SDL_Rect imgbg2Rect;

	SDL_Rect titre1DestRect;
	SDL_Rect titre2DestRect;
	SDL_Rect titre3DestRect;

	SDL_Rect opt1DestRect;
	SDL_Rect opt2DestRect;
	SDL_Rect opt3DestRect;

	// Le pointeur vers les polices
	TTF_Font *police = NULL;
	TTF_Font *police2 = NULL;
	TTF_Font *police3 = NULL;
	// Une variable de couleur noire
	SDL_Color white = {255, 255, 255};

    /* Initialisation simple */
	SDL_Init(SDL_INIT_VIDEO);

	/* Initialisation TTF */
	TTF_Init();


	/* Création de la fenêtre */
	pWindow = SDL_CreateWindow("The Biding of Isaac REMASTERED",SDL_WINDOWPOS_UNDEFINED,
																SDL_WINDOWPOS_UNDEFINED,
												 				1080,
												  				850,
												  				SDL_WINDOW_SHOWN|SDL_WINDOW_RESIZABLE);


	renderer = SDL_CreateRenderer(pWindow, -1, SDL_RENDERER_ACCELERATED);

	police = TTF_OpenFont("./ttf/upheavtt.ttf", 40);
	police2 = TTF_OpenFont("ttf/upheavtt.ttf", 30);
	police3 = TTF_OpenFont("ttf/upheavtt.ttf", 150);

	option1 = TTF_RenderUTF8_Blended(police, "JOUER", white);
	option2 = TTF_RenderUTF8_Blended(police, "REGLES", white);
	option3 = TTF_RenderUTF8_Blended(police, "QUITTER", white);

	SDL_Texture *option1_tex = SDL_CreateTextureFromSurface(renderer, option1);
	SDL_Texture *option2_tex = SDL_CreateTextureFromSurface(renderer, option2);
	SDL_Texture *option3_tex = SDL_CreateTextureFromSurface(renderer, option3);

	titre1 = TTF_RenderUTF8_Blended(police2, "the binding of", white);
	titre2 = TTF_RenderUTF8_Blended(police3, "ISAAC", white);
	titre3 = TTF_RenderUTF8_Blended(police2, "REMASTERED", white);

	SDL_Texture *titre1_tex = SDL_CreateTextureFromSurface(renderer, titre1);
	SDL_Texture *titre2_tex = SDL_CreateTextureFromSurface(renderer, titre2);
	SDL_Texture *titre3_tex = SDL_CreateTextureFromSurface(renderer, titre3);

	/* on a la texture, plus besoin du texte */
	SDL_FreeSurface(option1);
	SDL_FreeSurface(option2);
	SDL_FreeSurface(option3);

	SDL_FreeSurface(titre1);
	SDL_FreeSurface(titre2);
	SDL_FreeSurface(titre3);

	/* Positionnement des titres */
	titre1DestRect.x = 400;
	titre1DestRect.y = 65;

	titre2DestRect.x = 300;
	titre2DestRect.y = 60;

	titre3DestRect.x = 430;
	titre3DestRect.y = 190;


	/* Positionnement des textes dans les boutons */
  opt1DestRect.x = 470;
	opt1DestRect.y = 280;

	opt2DestRect.x = 460;
	opt2DestRect.y = 370;

	opt3DestRect.x = 450;
	opt3DestRect.y = 460;

	SDL_QueryTexture(option1_tex, NULL, NULL, &(opt1DestRect.w), &(opt1DestRect.h));
	SDL_QueryTexture(option2_tex, NULL, NULL, &(opt2DestRect.w), &(opt2DestRect.h));
	SDL_QueryTexture(option3_tex, NULL, NULL, &(opt3DestRect.w), &(opt3DestRect.h));

	SDL_QueryTexture(titre1_tex, NULL, NULL, &(titre1DestRect.w), &(titre1DestRect.h));
	SDL_QueryTexture(titre2_tex, NULL, NULL, &(titre2DestRect.w), &(titre2DestRect.h));
	SDL_QueryTexture(titre3_tex, NULL, NULL, &(titre3DestRect.w), &(titre3DestRect.h));


	//Chargement parchemin menu
	SDL_Texture *image_pa_tex = tex_img_png("./img/bgmenu.png",renderer);
	//Chargement parchemin menu
	SDL_Texture *image_parchemin_tex = tex_img_png("./img/fondmenu.png",renderer);
	//Chargement de l'image bouton
  SDL_Texture *image_btn_tex = tex_img_png("./img/btn.png",renderer);
  //Chargement de l'image bouton 
	SDL_Texture *image_btnHover_tex = tex_img_png("./img/btnHover.png",renderer);

	SDL_Texture *temp;

	SDL_FreeSurface(image);
	SDL_FreeSurface(image_hover);

	if( pWindow )
	{
		int running = 1;
		while(running) {
			SDL_Event e;
			while(SDL_PollEvent(&e)) {
				switch(e.type) {
					case SDL_QUIT: running = 0; break;
					case SDL_KEYDOWN:
					switch(e.key.keysym.sym){
					    case SDLK_ESCAPE: running = 0; break;
				    	case SDLK_DOWN:
						if(pos < 3 ){
							pos++;
						}
						else{
							pos=1;
						}break;
						case SDLK_UP:
							if(pos > 1){
								pos--;
							}
							else{
								pos=3;
							}
						break;
						case SDLK_RETURN:
							switch(pos){
								case 1: /* JOUER */
									SDL_DestroyWindow(pWindow);
									jeu();
								break;
								case 2: /* REGLES */
									SDL_DestroyWindow(pWindow);
									regle();
								break;
								case 3: /* QUITTER */
									running=0;
									break;
							}
						break;
					}
					case SDL_WINDOWEVENT:
						SDL_RenderClear(renderer);

						//BACKGROUND1
            imgbg2Rect.x = 0;
            imgbg2Rect.y = 0;
            SDL_QueryTexture(image_pa_tex, NULL, NULL, &(imgbg2Rect.w), &(imgbg2Rect.h));
						SDL_RenderCopy(renderer, image_pa_tex, NULL, &imgbg2Rect);

						//BACKGROUND2
            imgbgRect.x = 265;
            imgbgRect.y = 10;
            SDL_QueryTexture(image_parchemin_tex, NULL, NULL, &(imgbgRect.w), &(imgbgRect.h));
						SDL_RenderCopy(renderer, image_parchemin_tex, NULL, &imgbgRect);

            SDL_QueryTexture(image_btnHover_tex, NULL, NULL, &(imgBtnRect.w), &(imgBtnRect.h));
						//Positionnement du premier bouton
              imgBtnRect.x = 440;
              imgBtnRect.y = 260;
						if( pos == 1 ){
							temp = image_btnHover_tex;
						}
						else{
							temp = image_btn_tex;
						}
						SDL_RenderCopy(renderer,temp,NULL,&imgBtnRect);

						imgBtnRect.x=440;
						imgBtnRect.y=350;
						if( pos == 2 ){
							temp = image_btnHover_tex;
						}
						else{
							temp = image_btn_tex;
						}
						SDL_RenderCopy(renderer,temp,NULL,&imgBtnRect);

						imgBtnRect.x=440;
						imgBtnRect.y=440;
						if( pos == 3 ){
							temp = image_btnHover_tex;
						}
						else{
							temp = image_btn_tex;
						}
						SDL_RenderCopy(renderer,temp,NULL,&imgBtnRect);

						/* Affichage texte sur boutons */
						SDL_RenderCopy(renderer, option1_tex, NULL, &opt1DestRect);
						SDL_RenderCopy(renderer, option2_tex, NULL, &opt2DestRect);
						SDL_RenderCopy(renderer, option3_tex, NULL, &opt3DestRect);

						/* Affichage des titres */
						SDL_RenderCopy(renderer, titre1_tex, NULL, &titre1DestRect);
						SDL_RenderCopy(renderer, titre2_tex, NULL, &titre2DestRect);
						SDL_RenderCopy(renderer, titre3_tex, NULL, &titre3DestRect);

            /* On fait le rendu ! */
            SDL_RenderPresent(renderer);
					break;
				}
			}
		}
	}
	//Destruction de la fenetre

	SDL_DestroyWindow(pWindow);
	TTF_CloseFont(police); /* Doit être avant TTF_Quit() */
	TTF_Quit();
    SDL_Quit();

    return 0;
}
