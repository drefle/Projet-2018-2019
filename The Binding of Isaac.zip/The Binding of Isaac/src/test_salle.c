#include "tout.h"



int main(){
  int i = 0, j;
  t_salle * m_map[L][L];
  t_joueur * joueur = creer_joueur(L/2, L/2, M/2, N/2, 5);
  srand(time(NULL));
  init_map( m_map );/*Création de la map*/
  int m_pattern[4][NB_PATTERN][M][N];
  remplir_pattern( m_pattern );/*Lecture du fichier qui contient les différents pattern*/

	genmap(m_map, NB_SALLE);/*Remplissage de la map*/


  printf("Création de la salle : \n");
  t_salle * salle = creer_salle();

  if(salle == NULL){
    printf("Echec création de la salle\n");
    return 1;
  }
  else
    printf("Salle créer \n");


  printf("Ajout de 2 monstres :\n");
  printf("Nombre de monstre avant ajout = %d \n",salle->l_monstre->nb_elem);

  en_tete(salle->l_monstre);
  ajout_droit(salle->l_monstre,creer_monstre(1 ,1, 1));
  ajout_droit(salle->l_monstre,creer_monstre(1 ,1, 1));

  printf("Nombre de monstre aprés ajout = %d \n",salle->l_monstre->nb_elem);

  printf("Suppression des monstres :\n");

  oter_elt(salle->l_monstre);
  oter_elt(salle->l_monstre);

  printf("Nombre de monstre aprés Suppression = %d \n",salle->l_monstre->nb_elem);


  printf("Ajout de 2 projectiles :\n");
  printf("Nombre de projectile avant ajout = %d \n",salle->l_projectile->nb_elem);

  en_tete(salle->l_projectile);
  ajout_droit(salle->l_projectile,creer_projectile(1,1,1,1,1));
  ajout_droit(salle->l_projectile,creer_projectile(1,1,1,1,1));

  printf("Nombre de projectile aprés ajout = %d \n",salle->l_projectile->nb_elem);

  printf("Suppression des projectiles :\n");

  oter_elt(salle->l_projectile);
  oter_elt(salle->l_projectile);

  printf("Nombre de projectile aprés Suppression = %d \n",salle->l_projectile->nb_elem);


  for(i=0;i<L;i++){
    for(j=0;j<L;j++){
      if(m_map[i][j] != NULL){

        en_queue(m_map[i][j]->l_monstre);
      	while(!liste_vide(m_map[i][j]->l_monstre)){
      		oter_elt(m_map[i][j]->l_monstre);
      	}

        free(m_map[i][j]->l_monstre->drapeau);
        free(m_map[i][j]->l_monstre);

        en_queue(m_map[i][j]->l_projectile);
      	while(!liste_vide(m_map[i][j]->l_projectile)){
      		oter_elt(m_map[i][j]->l_projectile);
      	}

        free(m_map[i][j]->l_projectile->drapeau);
        free(m_map[i][j]->l_projectile);
        free(m_map[i][j]);
      }
    }
  }
  free(joueur);
  free(salle->l_monstre->drapeau);
  free(salle->l_projectile->drapeau);
  free(salle->l_monstre);
  free(salle->l_projectile);
  free(salle);

}
