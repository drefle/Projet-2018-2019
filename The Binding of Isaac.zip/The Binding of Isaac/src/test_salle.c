#include "tout.h"



int main(){

  printf("Création de la salle : \n");
  t_salle * salle = creer_salle();

  if(salle == NULL){
    printf("Echec création de la salle\n");
    return 1;
  }
  else
    printf("Salle créer \n");


  printf("Ajout de 2 monstres :\n");
  printf("Nombre de monstre avant ajout = %d \n",salle->l_monstre->nb_elem);

  en_tete(salle->l_monstre);
  ajout_droit(salle->l_monstre,creer_monstre(1 ,1, 1));
  ajout_droit(salle->l_monstre,creer_monstre(1 ,1, 1));

  printf("Nombre de monstre aprés ajout = %d \n",salle->l_monstre->nb_elem);

  printf("Suppression des monstres :\n");

  oter_elt(salle->l_monstre);
  oter_elt(salle->l_monstre);

  printf("Nombre de monstre aprés Suppression = %d \n",salle->l_monstre->nb_elem);


  printf("Ajout de 2 projectiles :\n");
  printf("Nombre de projectile avant ajout = %d \n",salle->l_projectile->nb_elem);

  en_tete(salle->l_projectile);
  ajout_droit(salle->l_projectile,creer_projectile(1,1,1,1,1));
  ajout_droit(salle->l_projectile,creer_projectile(1,1,1,1,1));

  printf("Nombre de projectile aprés ajout = %d \n",salle->l_projectile->nb_elem);

  printf("Suppression des projectiles :\n");

  oter_elt(salle->l_projectile);
  oter_elt(salle->l_projectile);

  printf("Nombre de projectile aprés Suppression = %d \n",salle->l_projectile->nb_elem);

  free(salle->l_monstre->drapeau);
  free(salle->l_projectile->drapeau);
  free(salle->l_monstre);
  free(salle->l_projectile);
  free(salle);

}
