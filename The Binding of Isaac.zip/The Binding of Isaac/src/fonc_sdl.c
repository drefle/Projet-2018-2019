#include "tout.h"

/**
* \file fonc_sdl.c
* \author Adrien P. - Paul PDC. - David C. - Paul C.
* \date 12/04/2019
* \brief Fonction d'obtention de la texture d'une image et structure de ressources (img)
*/

extern
SDL_Texture* tex_img_png(char * s, SDL_Renderer *renderer){

    SDL_RWops *rwop=SDL_RWFromFile(s, "rb");
	SDL_Surface *image=IMG_LoadPNG_RW(rwop);
	if(!image) {
	     printf("IMG_LoadPNG_RW: %s\n", IMG_GetError());
	}
	SDL_Texture *image_btn_tex = SDL_CreateTextureFromSurface(renderer, image);
	if(!image_btn_tex){
		fprintf(stderr, "Erreur à la création du rendu de l'image : %s\n", SDL_GetError());
		exit(EXIT_FAILURE);
	}
	SDL_FreeSurface(image); /* on a la texture, plus besoin de l'image */
  if(image_btn_tex!= NULL){
    return image_btn_tex;
  }
  else{
    return 0;
  }
}

extern
void init_res(t_res *ressource, SDL_Renderer *salle_render){
  ressource->sol_tex=tex_img_png("./img/sol.png",salle_render);
  ressource->obstacle_tex=tex_img_png("./img/obstacle.png",salle_render);
  ressource->case_vide_tex = tex_img_png("./img/case_vide.png",salle_render);
  ressource->porte_tex = tex_img_png("./img/porte.png",salle_render);

  ressource->perso_bas_tex = tex_img_png("./img/persobas.png",salle_render);
  ressource->perso_gauche_tex = tex_img_png("./img/persogauche.png",salle_render);
  ressource->perso_droite_tex = tex_img_png("./img/persodroite.png",salle_render);
  ressource->perso_haut_tex = tex_img_png("./img/persohaut.png",salle_render);


  ressource->monstre_tex = tex_img_png("./img/monstre.png",salle_render);
  ressource->projectile_tex = tex_img_png("./img/projectile.png",salle_render);
  ressource->coeur_tex = tex_img_png("./img/coeur.png",salle_render);
  ressource->coeur_sol_tex = tex_img_png("./img/coeur_sol.png",salle_render);

  ressource->salle_vu_tex = tex_img_png("./img/seen.png",salle_render);
  ressource->salle_clear_tex = tex_img_png("./img/clear.png",salle_render);
  ressource->joueur_map_tex = tex_img_png("./img/here.png",salle_render);

  ressource->cle_tex = tex_img_png ("./img/cle.png",salle_render);
  ressource->cle_ath_tex = tex_img_png ("./img/cle_ath.png",salle_render);
  ressource->sortie_tex = tex_img_png ("./img/sortie.png",salle_render);
  ressource->portail_tex = tex_img_png ("./img/portail.png",salle_render);

  /*fprintf(stderr,"ok init res");*/
}
