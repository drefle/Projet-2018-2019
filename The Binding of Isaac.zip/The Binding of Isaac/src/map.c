#include "tout.h"

/**
* \file map.c
* \author Adrien P. - Paul PDC. - David C. - Paul C.
* \date 16/04/2019 
* \brief Toutes les fonctions nécessaires à la génération de la map
*/


int x_salle_finale, y_salle_finale;
int x_salle_cle, y_salle_cle;

/*Initialise la map entière à NULL sauf la case du milieu où une salle est créée*/


extern
void init_map(t_salle * m_map[L][L]){
	int i,j;
	for(i=0 ; i<L ;i++){
		for(j=0 ; j<L ;j++){
			m_map[i][j]=NULL;
		}
	}
  m_map[L/2][L/2] = creer_salle();
}

/*Vérification de la validité des coordonnées*/

extern
int coord_valides(t_salle * m_map[L][L], int x, int y){

	if(m_map[x][y] != NULL){
		return 0;
	}

	if( ((x <= 0) || (x >= L-1)) || ((y <= 0) || (y >= L-1)) ){/*Les coordonnées sont bien dans la matrice*/
		return 0;
	}
	/*Vérifie si l'ajout des coordonnées passées en paramètres ne créé pas un carré de  4 salles*/

	if( (m_map[x][y-1]!= NULL) && (m_map[x-1][y]!= NULL) ){
		if(m_map[x-1][y-1]!= NULL){
			return 0;
		}
	}
	if( (m_map[x-1][y]!= NULL) && (m_map[x][y+1]!= NULL) ){
		if(m_map[x-1][y+1]!= NULL){
			return 0;
			}
		}
	if( (m_map[x+1][y]!= NULL) && (m_map[x][y-1]!= NULL) ){
		if(m_map[x+1][y-1]!= NULL){
			return 0;
			}
		}
	if( (m_map[x][y+1]!= NULL) && (m_map[x+1][y]!= NULL) ){
		if(m_map[x+1][y+1]!= NULL){
			return 0;
			}
		}
		return 1;
}

/*Ajoute ou supprime les coordonnées passées en paramètre de la liste de coordonnées*/
extern
void maj_coord_possible(t_salle * m_map[L][L], t_liste * l_coord , int x , int y){

	if( !coord_valides(m_map,x,y) ){
		t_coord * temp = creer_coord(-1,-1);

		en_tete(l_coord);
		valeur_elt_coord(l_coord, temp);
		while( (( temp->absi != x ) || ( temp->ord != y )) && ( !hors_liste(l_coord) ) ){/*Recherche dans la liste les coordonnées afin de les enlevées*/
			suivant(l_coord);
			valeur_elt_coord(l_coord, temp);
		}
		if( !hors_liste(l_coord) ){
			oter_elt(l_coord);
		}
		free(temp);
	}
	else{
		en_tete(l_coord);
		ajout_droit(l_coord, creer_coord(x,y) );
	}

}

/*Fonction principale de la génération de la map*/

extern
void genmap(t_salle * m_map[L][L], int n){
	int i, j;
	int salle_cle = rand() % (n-1);
	t_liste * l_coord = malloc(sizeof(t_liste));
	t_coord * coord = creer_coord(-1,-1);
	int x = L/2;
	int y = L/2;
	int choix_coord;
	init_liste(l_coord,supprimer_coord_cb);

	for( i=0 ; i<n ; i++ ){/*Valide ou non l'ajout des coordonnées des salles adjacentes à la liste des coordonnées*/
		maj_coord_possible(m_map,l_coord,x,y-1);
		maj_coord_possible(m_map,l_coord,x-1,y);
		maj_coord_possible(m_map,l_coord,x+1,y);
		maj_coord_possible(m_map,l_coord,x,y+1);

		choix_coord =	rand()%(l_coord->nb_elem);

		en_tete(l_coord);
		for( j=0 ; j<choix_coord ; j++ ){/*Le choix de la salle ajouté est fait aléatoirement, elle est ensuite supprimée de la liste*/
			suivant(l_coord);
		}
		valeur_elt_coord(l_coord,coord);
		oter_elt(l_coord);

		x = coord->absi;
		y = coord->ord;
		m_map[x][y] = creer_salle();

		if(i == salle_cle){
			x_salle_cle = x;
			y_salle_cle = y;
		}
	}
	x_salle_finale = x;
	y_salle_finale = y;

/* Liberation mémoire */

	en_queue(l_coord);
	while(!liste_vide(l_coord)){
		oter_elt(l_coord);
	}

	free(l_coord->drapeau);
	free(l_coord);
	free(coord);
/*-------------------*/

	for( i=0 ; i<L ; i++){
		for( j=0 ; j<L ; j++){
			if( m_map[i][j] != NULL ){
				init_salle(m_map, i, j);
			}
		}
	}
}


extern
void maj_map(t_salle * m_map[L][L], int x, int y){
  if( (m_map[x+1][y] != NULL) && (m_map[x+1][y]->etat == CACHE) ){
    m_map[x+1][y]->etat = VU;
  }
  if( (m_map[x-1][y] != NULL) && (m_map[x-1][y]->etat == CACHE) ){
    m_map[x-1][y]->etat = VU;
  }
  if( (m_map[x][y+1] != NULL) && (m_map[x][y+1]->etat == CACHE) ){
    m_map[x][y+1]->etat = VU;
  }
  if( (m_map[x][y-1] != NULL) && (m_map[x][y-1]->etat == CACHE) ){
    m_map[x][y-1]->etat = VU;
  }
}
