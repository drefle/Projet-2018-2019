#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <ncurses.h>
#include <time.h>
#include <ncurses.h>
#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include <SDL2/SDL_image.h>

/**
* \file tout.h
* \author Adrien P. - Paul PDC. - David C. - Paul C.
* \date 12/04/2019
* \brief Primitives des fonctions, variables globales et structures de données
*/

#define N 46 /* Longeur de la salle */
#define M 26 /* Largeur de la salle */
#define L 10

#define     TICK 15
#define NB_SALLE 4

#define NB_PATTERN 3

/* Codes pour le remplissage de la salle */
#define        SOL 0
#define     JOUEUR 1
#define        MUR 2
#define      PORTE 3
#define    MONSTRE 4
#define        VIE 5
#define        CLE 6
#define     SORTIE 7
#define PROJECTILE 8


typedef struct s_joueur t_joueur;
typedef struct s_monstre t_monstre;
typedef struct s_coord t_coord;
typedef struct s_projectile t_projectile;
typedef struct s_salle t_salle;
typedef struct s_element t_element;
typedef struct s_liste t_liste;
typedef struct s_res t_res;

/*######################COORD######################*/

struct s_coord{
  int absi;           /*!< Abscisse des coordonnées */
  int ord;            /*!< Ordonnées des coordonnées */
};

extern
t_coord * creer_coord(int absi, int ord);
/**
* \fn t_coord * creer_coord(int absi, int ord)
* \brief Création de coordonnées
* \param absi est l'abscisse
* \param ord est l'ordonnée
*/

extern
void supprimer_coord_cb(void * a);
/**
* \fn void supprimer_coord_cb(void * a)
* \brief  appelle la fonction supprimer_coord
* \param  a pointeur sur des coordonnées
*/

/*###################### LISTE PTR ######################*/

/* STRUCTURE */
struct s_element{
  void * p_val;
  struct s_element* pred;
  struct s_element* succ;
};

/* STRUCTURE */
struct s_liste{
  void (*supprimer_elem)(void *);
  t_element* drapeau;
  t_element* ec;
  int nb_elem;
};

extern
void init_liste(t_liste * liste, void (*supprimer_elem)(void *));

extern
int liste_vide(t_liste * liste);

extern
int hors_liste(t_liste * liste);

extern
void en_tete(t_liste * liste);

extern
void en_queue(t_liste * liste);

extern
void precedent(t_liste * liste);

extern
void suivant(t_liste * liste);

extern
void valeur_elt_coord(t_liste * liste, t_coord*  coord);

extern
void modif_elt(t_liste * liste, void * v);

extern
void oter_elt(t_liste * liste);

extern
void ajout_droit(t_liste * liste, void * pt);

extern
void ajout_gauche(t_liste * liste, void * pt);

/*##################SALLE##########################*/

/* STRUCTURE */
/**
 * \enum t_etat
 * \brief Structure d'états des salles
 */

typedef enum {
  CACHE,  /*!<SAlle non visible */
  VU,     /*!<Salle visible depuis celle ou le joueur se trouve*/
  VIDE    /*!<Tous les monstres sont tués*/
} t_etat;

/**
 * \struct s_salle
 * \brief Composantes d'une salle
 */
struct s_salle{
    int m_salle[M][N];      /*!<Matrice de la salle */
    t_liste * l_monstre;    /*!<Liste des montres */
    t_liste * l_projectile; /*!<Liste des projectiles */
    t_etat etat;            /*!< Etat de la salle */
};


/* FONCTIONS */

extern
t_salle * creer_salle();
/**
* \fn t_salle * creer_salle()
* \brief Créer la salle (allocation mémoire pour la structure salle et les listes montre et projectile + définition de l'etat de la salle)
*/

extern void maj_salle_finale(t_salle * salle, int i);
/**
* \fn extern void maj_salle_finale(t_salle * salle, int i)
* \brief Met à jour la salle finale
* \param salle La salle finale
* \param Un compteur qui est incrementer de 1 entre chaque appelle de la fonction
*/

extern
void init_salle(t_salle * m_map[L][L], int x, int y);
/**
* \fn void init_salle(t_salle * m_map[L][L], int x, int y)
* \brief Création des mur, des portes ,des obstacles et des montres
* \param m_map[L][L] Matrice contenant des pointeurs sur salle
* \param x Coordonnée sur la map
* \param y Coordonnée sur la map
*/

extern
void afficher_salle(t_salle * m_map[L][L],int mat[M][N],SDL_Renderer *salle_render,t_res *ressource,t_joueur * joueur);
/**
* \fn afficher_salle(t_salle * m_map[L][L],int mat[M][N],SDL_Renderer *salle_render,t_res *ressource,t_joueur * joueur);
* \brief Affichage de la salle, de la map et des vies
* \param t_salle_*_m_map[L][L] Matrice (map) de pointeurs sur la salle actuelle
* \param mat[M][N] Matrice de la salle
* \param SDL_Renderer_*salle_render Rendu de la salle
* \param t_res_*_ressource Pointeur sur la structure ressource
* \param t_joueur_*_joueur Pointeur sur la structure joueur
*/

extern
void creer_mat_distance(int mat[M][N], int mat_distance[N][N]);
/**
* \fn creer_mat_distance(int mat[M][N], int mat_distance[N][N])
* \brief Remplie une matrice avec la distance au joueur en chaque case
* \details Algorithme de chemin le plus court
* \param mat[M][N] Matrice de la salle
* \param mat_distance[N][N] Matrice de distance
*/

extern
void afficher_mat_distance(int mat_distance[M][N]);
/**
* \fn void afficher_mat_distance(int mat_distance[M][N])
* \brief Affiche la mat_distance[M][N]
* \details Utilisée pour des tests
* \param mat_distance[M][N] Matrice de distance à afficher
*/

extern
void remplir_pattern(int m_pattern[4][NB_PATTERN][M][N]);
/**
* \fn void remplir_pattern(int m_pattern[4][NB_PATTERN][M][N])
* \brief Remplie la matrice m_pattern[4][NB_PATTERN][M][N] grâce à un fichier.txt
* \param mat_distance[M][N] Matrice à remplir
*/


/*################### MAP #########################*/

extern
void init_map(t_salle * m_map[L][L]);
/**
* \fn void init_map(t_salle * m_map[L][L])
* \brief Initialise la map a NULL sauf la salle centrale
* \param m_map[L][L] Matrice (map) de pointeurs de salles
*/

extern
int coord_valides(t_salle * m_map[L][L], int x, int y);
/**
* \fn int coord_valides(t_salle * m_map[L][L], int x, int y)
* \brief Vérifie si les coordonnées sont valides pour la création de la map
* \param m_map[L][L] Matrice (map) de pointeurs de salles
* \param x Coordonnées sur la map
* \param y Coordonnées sur la map
*/

extern
void maj_coord_possible(t_salle * m_map[L][L], t_liste * l_coord , int x , int y);
/**
* \fn void maj_coord_possible(t_salle * m_map[L][L], t_liste * l_coord , int x , int y)
* \brief Vérifie que l'ajout de la salle dans la liste de salle est possible
* \param m_map[L][L] Matrice (map) de pointeurs de salles
* \param l_coord liste de coordonnées de salle dans la matrice
* \param x Coordonnées sur la map
* \param y Coordonnées sur la map
*/

extern
void genmap(t_salle * m_map[L][L], int n);
/**
* \fn void genmap(t_salle * m_map[L][L], int n)
* \brief Effectue la génération aléatoire de la map
* \param m_map[L][L] Matrice (map) de pointeurs de salles
* \param n nombre de salle générées dans la map
*/

extern
void maj_map(t_salle * m_map[L][L], int x, int y);
/**
* \fn void maj_map(t_salle * m_map[L][L], int x, int y)
* \brief met à jour l'etat des salle
* \param m_map[L][L] Matrice (map) de pointeurs sur la salle actuelle
* \param x Coordonnées sur la map
* \param y Coordonnées sur la map
*/



/*########################## JOUEUR ##############################*/
/**
 * \struct s_joueur
 * \brief Caractèristique du joueur
 */
struct s_joueur{
    int x_map;        /*!< Position dans la map */
    int y_map;        /*!< Position dans la map */
    int x_salle;      /*!< Position dans la salle */
    int y_salle;      /*!< Position dans la salle */
    int x_mouv;       /*!< Prochaine coordonée (mouvement abscisse) */
    int y_mouv;       /*!< Prochaine coordonnée (mouvement ordonnée ) */
    int x_direction;  /*!< Direction (abscice) */
    int y_direction;  /*!< Direction (ordonnée) */
    int pv;           /*!< Points de vie */
    int cle;          /*!< Possesion de la clé */
    int victoire;     /*!< Victoire ? */
};

/* FONCTIONS */

extern
t_joueur * creer_joueur(int xm, int ym, int xs, int ys, int  pv);
/**
* \fn t_joueur * creer_joueur(int xm, int ym, int xs, int ys, int pv)
* \brief Créer un joueur le positionne à la base de la map et centre de la 1ere salle et lui donne un certain nombre de pv
* \param xm Coordonnée dans la map
* \param ym Coordonnée dans la map
* \param xs Coordonnée dans la salle
* \param ys Coordonnée dans la salle
*/

extern
int est_franchissable(int x, int y, int salle[M][N]);
/**
* \fn int est_franchissable(int x, int y, int salle[M][N])
* \brief Verifie si la coordonnée n'est pas un obstacle, bordure, porte etc.
* \param x Coordonnée dans la salle
* \param y Coordonnée dans la salle
* \param salle[M][N] Matrice de la salle
*/

extern
void deplacer_joueur(t_salle * m_map[L][L], t_joueur * joueur);
/**
* \fn void deplacer_joueur(t_salle * m_map[L][L], t_joueur * joueur)
* \brief Changement de position du joueur si la coordonée suivant est franchissable
* \param t_salle * m_map[L][L]
* \param t_joueur_*_joueur Pointeur sur la structure joueur
*/

extern
void controle_joueur(t_joueur * joueur, t_salle * m_map[L][L],SDL_Keycode key);
/**
* \fn void controle_joueur(t_joueur * joueur, t_salle * m_map[L][L])
* \brief Récuperation des touches utilisé pour déplacement du joueur,
* \param t_joueur_*_joueur Pointeur sur la structure joueur
* \param t_salle_*_m_map[L][L] Matrice (map) de pointeurs de salles
* \param SDL_Keycode_key Valeur de la touche pressée par le joueur
*/



/*################### MONSTRE #########################*/

typedef enum {H, V} t_dir;
struct s_monstre{
  int x_salle;        /*!< Position dans la salle */
  int y_salle;        /*!< Position dans la salle */
  int x_mouv;         /*!< Déplacement du monstre */
  int y_mouv;         /*!< Déplacement du monstre */
  int vitesse;        /*!< Vitesse de déplacement du monstre */
  t_dir last_dir;     /*!< Dernière direction du monstre (verticale ou horyzontale) */
};


extern
t_monstre * creer_monstre(int x_salle, int y_salle, int vit);
/**
* \fn t_monstre * creer_monstre(int x_salle, int y_salle, int vit)
* \brief Créer un monstre avec des coordonnées et une vitesse
* \param x_salle Coordonnée dans la salle
* \param y_salle Coordonnée dans la salle
* \param vit Vitesse du monstre
*/

extern
void supprimer_monstre_cb(void * a);
/**
* \fn void supprimer_monstre_cb(void * a)
* \brief appelle la fonction supprimer_monstre
* \param a un pointeur de monstre
*/

extern
void deplacer_monstre(t_salle * salle, t_joueur * j, int i);
/**
* \fn void deplacer_monstre(t_salle * salle, t_joueur * j, int i)
* \brief Permet aux monstre de se déplacer vers le joueur en prenant le chemin le plus court
* \param salle Pointeur sur la salle dans laquelle est présent le joueur
* \param j Pointeur sur la stucture du joueur
* \param i variable permettant d'actualiser ou non la position du projectile
*/
/*
#####################################"PROJECTILE"################################
*/

/* STRUCTURE */
struct s_projectile{
  int x;              /*!< Position dans la salle */
  int y;              /*!< Position dans la salle */
  int mouv_x;         /*!< Déplacement du projectile */
  int mouv_y;         /*!< Déplacement du projectile */
  int vitesse;        /*!< Vitesse du projectile */
};


extern
void supprimer_projectile_cb(void * p);
/**
* \fn void supprimer_projectile_cb(void * p)
* \brief appelle la fonction supprimer_projectile
* \param p un pointeur sur projectile
*/

extern
t_projectile * creer_projectile(int x,int y,int mouv_x,int mouv_y,int vit);
/**
* \fn t_projectile * creer_projectile(int x,int y,int mouv_x,int mouv_y,int vit)
* \brief créer un projectile avec des coordonnées, une direction et une vitesse (tous passé en paramètre)
* \param x et y les coordonnées du projectile dans la salle
* \param mouv_x et mouv_y la direction du projectile
* \param vit la vitesse du projectile
*/

extern
void tirer_projectile(t_salle * salle, int x, int y, int mouv_x, int mouv_y, int vit);
/**
* \fn void tirer_projectile(t_salle * salle, int x, int y, int mouv_x, int mouv_y, int vit)
* \brief Vérifie si le projectile peut être créer et gére le cas où le projectile et créer sur un montre (en le supprimant)
* \param salle la salle courante
* \param x et y les coordonnées du projectile dans la salle
* \param mouv_x et mouv_y la direction du projectile
* \param vit la vitesse du projectile
*/

extern
void deplacer_projectile(t_salle * salle, t_joueur * j,int i);
/**
* \fn deplacer_projectile(t_salle * salle, t_joueur * j,int i)
* \brief Déplace et gère la collision des projectile avec les mur, les monstres et le joueur
* \param salle la salle courante
* \param j le joueur
* \param i variable permettant d'actualiser ou non la position du projectile
*/

/**
 * \struct s_res
 * \brief Structure de toutes les textures des objets du jeux
 */

struct s_res{
  SDL_Texture *obstacle_tex ;
  SDL_Texture *case_vide_tex;
  SDL_Texture *perso_bas_tex;
  SDL_Texture *perso_haut_tex;
  SDL_Texture *perso_gauche_tex;
  SDL_Texture *perso_droite_tex;
  SDL_Texture *porte_tex ;
  SDL_Texture *monstre_tex ;
  SDL_Texture *projectile_tex ;
  SDL_Texture *sol_tex;
  SDL_Texture *coeur_tex;
  SDL_Texture *coeur_sol_tex;
  SDL_Texture *salle_vu_tex;
  SDL_Texture *salle_clear_tex;
  SDL_Texture *joueur_map_tex;
  SDL_Texture *cle_tex;
  SDL_Texture *cle_ath_tex;
  SDL_Texture *sortie_tex;
  SDL_Texture *portail_tex;
};

extern
SDL_Texture* tex_img_png(char * s, SDL_Renderer *renderer);
/**
* \fn SDL_Texture* tex_img_png(char * s, SDL_Renderer *renderer)
* \brief Renvoie une texture à partir d'une image
* \param s Le nom de l'image
* \param renderer Moteur de rendu dans lequel est mis la texture
*/

extern
void init_res(t_res *ressource, SDL_Renderer *salle_render);
/**
* \fn void init_res(t_res *ressource, SDL_Renderer *salle_render)
* \brief Initialise les textures nécessaires à l'affichage des salles et du contenu sdl en général
* \param ressource Les ressources textures
* \param salle_render Moteur de rendu dans lequel sera affiché les textures
*/
