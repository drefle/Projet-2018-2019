#include "tout.h"

/**
* \file salle.c
* \author Adrien P. - Paul PDC. - David C. - Paul C.
* \date 17/04/2019
* \brief Toutes les fonctions concernant la création, l'actualisation et l'affichage des salles
*/

int nb_mob_tot = 0;
extern int x_salle_finale, y_salle_finale;
extern int x_salle_cle, y_salle_cle;


extern
t_salle * creer_salle(){
    t_salle * salle = malloc(sizeof(t_salle));

    salle->l_monstre = malloc(sizeof(t_liste));
    init_liste(salle->l_monstre, supprimer_monstre_cb);

    salle->l_projectile = malloc(sizeof(t_liste));
    init_liste(salle->l_projectile, supprimer_projectile_cb);

    salle->etat = CACHE;
    return salle;
}

void init_salle_finale(t_salle * salle){
  nb_mob_tot += 8;
  en_tete(salle->l_monstre);
  ajout_droit(salle->l_monstre,creer_monstre(11, 21, (rand() % 2) + 3 ));
  salle->m_salle[11][21] = MONSTRE;

  ajout_droit(salle->l_monstre,creer_monstre(14, 21, (rand() % 2) + 3 ));
  salle->m_salle[14][21] = MONSTRE;

  ajout_droit(salle->l_monstre,creer_monstre(14, 24, (rand() % 2) + 3 ));
  salle->m_salle[14][24] = MONSTRE;

  ajout_droit(salle->l_monstre,creer_monstre(11, 24, (rand() % 2) + 3 ));
  salle->m_salle[11][24] = MONSTRE;

  ajout_droit(salle->l_monstre,creer_monstre(5, 17, (rand() % 2) + 3 ));
  salle->m_salle[5][17] = MONSTRE;

  ajout_droit(salle->l_monstre,creer_monstre(5, 28, (rand() % 2) + 3 ));
  salle->m_salle[5][28] = MONSTRE;

  ajout_droit(salle->l_monstre,creer_monstre(21, 17, (rand() % 2) + 3 ));
  salle->m_salle[21][17] = MONSTRE;

  ajout_droit(salle->l_monstre,creer_monstre(21, 28, (rand() % 2) + 3 ));
  salle->m_salle[21][28] = MONSTRE;


  for(int i = 17;i<29;i++){
    salle->m_salle[3][i] = 2;
    salle->m_salle[22][i] = 2;
  }
  salle->m_salle[10][20] = 2;
  salle->m_salle[10][21] = 2;
  salle->m_salle[10][24] = 2;
  salle->m_salle[10][25] = 2;
  salle->m_salle[15][20] = 2;
  salle->m_salle[15][21] = 2;
  salle->m_salle[15][24] = 2;
  salle->m_salle[15][25] = 2;
  salle->m_salle[11][20] = 2;
  salle->m_salle[11][25] = 2;
  salle->m_salle[14][20] = 2;
  salle->m_salle[14][25] = 2;

  salle ->m_salle[12][22] = SORTIE;
  salle ->m_salle[12][23] = SORTIE;
  salle ->m_salle[13][22] = SORTIE;
  salle ->m_salle[13][23] = SORTIE;

}

extern void maj_salle_finale(t_salle * salle, int i){
  if(i % 20 == 0){
    tirer_projectile(salle,24,1,-1,1,1);
    tirer_projectile(salle,1,1,1,1,1);
    tirer_projectile(salle,24,44,-1,-1,1);
    tirer_projectile(salle,1,44,1,-1,1);

    tirer_projectile(salle,4,17,1,-1,1);
    tirer_projectile(salle,22,17,-1,-1,1);
    tirer_projectile(salle,4,28,1,1,1);
    tirer_projectile(salle,22,28,-1,1,1);
  }

}


static
void init_pattern(int m_pattern[4][NB_PATTERN][M][N]){
  int i, j, k, l ;
  for( i=0 ; i<4 ; i++){
    for( j=0 ; j<NB_PATTERN ; j++ ){
      for( k=0 ; k<M ; k++ ){
        for( l=0 ; l<N ; l++ ){
          m_pattern[i][j][k][l] = 0;
        }
      }
    }
  }
}


extern
void remplir_pattern(int m_pattern[4][NB_PATTERN][M][N]){
  FILE* fichier;
  int coin = 0;
  int choix = 0;
  int x;
  int y;
  fichier = fopen("./fichier/pattern.txt","r");

  init_pattern(m_pattern);

  do{
    fscanf(fichier,"%i %i", &x, &y);
    if( x<0 ){
      if( y == -1 ){
        choix++;
      }
      else{
        coin++;
        choix = 0;
      }
    }else{
      m_pattern[coin][choix][x][y] = 1;
    }


  }while( (coin < 4) && (choix < NB_PATTERN) );

  fclose(fichier);
}


extern
void init_salle(t_salle * m_map[L][L], int x, int y){
  int i, j, k;
  int x_mob, y_mob,x_cle ,y_cle , nb_mob ;
  int choix_HG, choix_HD, choix_BG, choix_BD ;
  int m_pattern[4][NB_PATTERN][M][N];


  for( i=0 ; i<M ; i++){
      for( j=0 ; j<N ; j++){
          m_map[x][y]->m_salle[i][j] = SOL;    /* Corps de la salle */
          /* BORDURES */
          m_map[x][y]->m_salle[0][j] = MUR;    /* haut */
          m_map[x][y]->m_salle[i][0] = MUR;    /* gauche */
          m_map[x][y]->m_salle[M-1][j] = MUR;  /* bas */
          m_map[x][y]->m_salle[i][N-1] = MUR;  /* droit */
      }
    }
/*Création des portes */
    if(m_map[x][y+1] != NULL){ /* Si salle à droite */
        for( i = 0 ; i < 3 ; i++){

           m_map[x][y]->m_salle[(M/2) + i][N-1] = PORTE;
           m_map[x][y]->m_salle[(M/2) - i][N-1] = PORTE;
       }
    }
    if(m_map[x][y-1] != NULL){ /* Si salle à gauche */
        for( i = 0 ; i < 3 ; i++){
           m_map[x][y]->m_salle[(M/2) + i][0] = PORTE;
           m_map[x][y]->m_salle[(M/2) - i][0] = PORTE;
       }
    }
    if(m_map[x+1][y] != NULL){ /* Si salle en bas */
        for( i = 0 ; i < 3 ; i++){
           m_map[x][y]->m_salle[M-1][(N/2) + i] = PORTE;
           m_map[x][y]->m_salle[M-1][(N/2) - i] = PORTE;
       }
    }
    if(m_map[x-1][y] != NULL){  /* Si salle en haut */
        for( i = 0 ; i < 3 ; i++){
           m_map[x][y]->m_salle[0][(N/2) + i] = PORTE;
           m_map[x][y]->m_salle[0][(N/2) - i] = PORTE;
       }
    }
  /*Fin création portes*/
  /*Création des obstacles*/
  if(x == x_salle_finale && y == y_salle_finale){ /*Si on traitre la salle finale */
    init_salle_finale(m_map[x][y]);
  }
  else{
    remplir_pattern(m_pattern);


    choix_HG = rand() % NB_PATTERN;
    choix_HD = rand() % NB_PATTERN;
    choix_BG = rand() % NB_PATTERN;
    choix_BD = rand() % NB_PATTERN;
    for( i=0 ; i<M ; i++){
      for( j=0 ; j<N ; j++){
        if( m_pattern[0][choix_HG][i][j] || m_pattern[1][choix_HD][i][j] || m_pattern[2][choix_BG][i][j] || m_pattern[3][choix_BD][i][j] ){
          m_map[x][y]->m_salle[i][j] = MUR;
        }
      }
    }

    /*Fin création obstacles*/
    /* Création des monstre */
    if( (x!=L/2) || (y!=L/2) ){
      nb_mob=(rand()%3)+2;
      nb_mob_tot += nb_mob;
      for(k=0 ; k < nb_mob ; k++){
        do{
          x_mob = ( rand() % (M-5) ) + 2;
          y_mob = ( rand() % (N-5) ) + 2;
        }while(m_map[x][y]->m_salle[x_mob][y_mob] != 0);
        en_tete(m_map[x][y]->l_monstre);
        ajout_droit(m_map[x][y]->l_monstre,creer_monstre(x_mob ,y_mob, (rand() % 2) + 3 ));
        m_map[x][y]->m_salle[x_mob][y_mob] = MONSTRE;
      }

    }
    else{
      m_map[L/2][L/2]->etat = VIDE;
      maj_map(m_map, L/2, L/2);
    }
    if(x==x_salle_cle && y==y_salle_cle){
      do{
        x_cle = ( rand() % (M-5) ) + 2;
        y_cle = ( rand() % (N-5) ) + 2;
      }while(m_map[x][y]->m_salle[x_cle][y_cle] != 0);
      m_map[x][y]->m_salle[x_cle][y_cle] = CLE;
    }
  }
}

/* Affichage de la matrice */
extern
void afficher_salle(t_salle * m_map[L][L],int mat[M][N],SDL_Renderer *salle_render,t_res *ressource, t_joueur * joueur){
  int i, j;
  SDL_Rect salle;
  SDL_Texture *temp;

  SDL_RenderClear(salle_render);
  SDL_QueryTexture(ressource->case_vide_tex, NULL, NULL, &(salle.w), &(salle.h));

/*Affichage de la salle en sdl*/
  for( i=0 ; i<M ; i++){
    salle.y = i*30;
    salle.x =0;
    for( j=0 ; j<N ; j++){
      if(mat[i][j] == SOL){
        temp=ressource->sol_tex;
      }
      else if(mat[i][j] == JOUEUR){
        if(joueur->x_direction == -1){
          temp=ressource->perso_haut_tex;
        }
        else if(joueur->y_direction == 1){
          temp=ressource->perso_droite_tex;
        }
        else if(joueur->y_direction == -1){
          temp=ressource->perso_gauche_tex;
        }
        else{
          temp=ressource->perso_bas_tex;
        }
      }
      else if(mat[i][j] == MUR) {
        temp=ressource->obstacle_tex;
      }
      else if(mat[i][j] == PORTE) {
        temp=ressource->porte_tex;
      }
      else if(mat[i][j] == MONSTRE){
        temp=ressource->monstre_tex;
      }
      else if(mat[i][j] == PROJECTILE){
        temp=ressource->projectile_tex;
      }
      else if(mat[i][j] == CLE) {
        temp=ressource->cle_tex;
      }
      else if(mat[i][j] == VIE) {
          temp=ressource->coeur_sol_tex;
      }
      else if(mat[i][j] == SORTIE && nb_mob_tot == 0 && joueur->cle == 1) {
        temp=ressource->portail_tex;
      }
      else if(mat[i][j] == SORTIE) {
        temp=ressource->sortie_tex;
      }
      SDL_RenderCopy(salle_render,temp,NULL,&salle);
      salle.x += 30;
    }
  }
  /*---------------------------------------------------------*/
  
  /*Affichage des coeurs à droite de la salle, en sdl*/
  salle.y=0;
  salle.x+=30;
  for( i = 0 ; i < joueur->pv ; i++){
    temp = ressource->coeur_tex;
    SDL_RenderCopy(salle_render,temp,NULL,&salle);
    salle.x += 25;
  }
  /*----------------------------------*/
  salle.x -= 25*(joueur->pv);
/*Affichage de la clé sous les coeurs, en sdl*/
  if(joueur->cle == 1){
    salle.y = 30;
    temp = ressource->cle_ath_tex;
    SDL_RenderCopy(salle_render,temp,NULL,&salle);
  }
/*----------------------------*/
/*Affichage de la mini_map évolutive à droite de la salle, en sdl*/
  salle.y = 60;
  for( i=0; i<L ;i++){
    salle.y +=30;
		for( j=0 ; j<L ;j++){
			if( (m_map[i][j]) && (m_map[i][j]->etat != CACHE) ){
        if(m_map[i][j]->etat == VU){
          temp=ressource->salle_vu_tex;
        }else{
          temp=ressource->salle_clear_tex;
        }
				if( (i==joueur->x_map) && (j==joueur->y_map) ){
          temp=ressource->joueur_map_tex;
				}
        SDL_RenderCopy(salle_render,temp,NULL,&salle);
			}
      salle.x += 30;
		}
    salle.x -= 300;
	}
/*----------------------------------------------------------*/
SDL_RenderPresent(salle_render);
}

void creer_mat_distance(int mat[M][N], int mat_distance[M][N]){
  int i,j,n;
  int est_pleine;

  for( i=0 ; i<M ; i++){
        for( j=0 ; j<N ; j++){
            /* BORDURES */
          if( mat[i][j] == MUR || mat[i][j] == PORTE || mat[i][j] == PROJECTILE || mat[i][j] == VIE || mat[i][j] == SORTIE)
            mat_distance[i][j] = -1; /* Obstacles */
          else if( mat[i][j] == JOUEUR )
            mat_distance[i][j] = 1; /* Position joueur */
          else
            mat_distance[i][j] = 0; /* Corps de la salle */
        }
    }

    n = 1;
    est_pleine = 0;
    while( !est_pleine ){
      est_pleine = 1;
      for( i=0 ; i<M ; i++){
        for( j=0 ; j<N ; j++){
          if( mat_distance[i][j] == n ){
            if( mat_distance[i+1][j] == 0 ){
              mat_distance[i+1][j] = n+1;
              est_pleine = 0;
            }
            if( mat_distance[i][j+1] == 0 ){
              mat_distance[i][j+1] = n+1;
              est_pleine = 0;
            }
            if( mat_distance[i-1][j] == 0 ){
              mat_distance[i-1][j] = n+1;
              est_pleine = 0;
            }
            if( mat_distance[i][j-1] == 0 ){
              mat_distance[i][j-1] = n+1;
              est_pleine = 0;
            }
          }
        }
      }
      n++;
    }
}

extern
void afficher_mat_distance(int mat_distance[M][N]){
  int i, j;

  for( i=0 ; i<M ; i++){
    for( j=0 ; j<N ; j++){
      printf("%2d|", mat_distance[i][j]);
    }
    printf("\n");
  }
}
