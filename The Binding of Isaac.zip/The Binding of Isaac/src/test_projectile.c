#include "tout.h"



int main(){

  t_salle * salle = creer_salle();
  t_joueur * joueur = creer_joueur(1,1,10,30,3); /* Création d'un joueur aux coordonnées x=10,y=30 et avec 3 point de vie */
  salle->m_salle[10][30] = JOUEUR;
  t_projectile * p;
  int i;

  salle->m_salle[10][10] = MUR; /* NOTRE OBSTACLE */


 /*----Test de tire d'un projectile dans une case non vide----*/


  printf("\n");
  printf("Test de tire d'un projectile dans une case non vide :\n");
  tirer_projectile(salle,10,9,0,1,1);
  p = salle->l_projectile->ec->p_val;
  if(salle->l_projectile->nb_elem == 1)
    printf("  Le projectile a été crée aux coordonnées : x = %d  y = %d \n",p->x,p->y);
  else
    printf("  Le projectile n'a pas été crée\n");

  printf("\n");


 /*----Test de tire d'un projectile avec un obstacle situer à 5 cases----*/


  i=0;
  printf("Test de tire d'un projectile avec un obstacle situer à 5 cases :\n");
  tirer_projectile(salle,10,5,0,1,1);
  p = salle->l_projectile->ec->p_val;
  if(salle->l_projectile->nb_elem == 1)
    printf("  Le projectile a été crée aux coordonnées : x = %d  y = %d \n",p->x,p->y);
  else
    printf("  Le projectile n'a pas été crée\n");

  while(!liste_vide(salle->l_projectile) && i<5){
    deplacer_projectile(salle,joueur,i);
    i++;
  }
  if(i==4)
    printf("  Le projectile s'est bien supprimer en rencontrant l'obstacle aprés %i ticks\n",i);
  printf("\n");



 /*----Test de tire d'un projectile avec un obstacle situer à 5 cases avec une vitesse de 2----*/

  i=0;
  printf("Test de tire d'un projectile avec un obstacle situer à 5 cases avec une vitesse de 2 :\n"); /*Avec un vitesse de 2, le projectile n'avance qu'une fois sur deux lors de l'appelle de la fonction deplacer_projectile */
  tirer_projectile(salle,10,5,0,1,2);
  p = salle->l_projectile->ec->p_val;
  if(salle->l_projectile->nb_elem == 1)
    printf("  Le projectile a été crée aux coordonnées : x = %d  y = %d \n",p->x,p->y);
  else
    printf("  Le projectile n'a pas été crée\n");

  while(!liste_vide(salle->l_projectile) && i<8){
    deplacer_projectile(salle,joueur,i);
    i++;
  }
  if(i==7)
    printf("  Le projectile s'est bien supprimer en rencontrant l'obstacle aprés %i ticks\n",i);
  printf("\n");


   /*----Test de tire d'un projectile avec un monstre situer à 5 cases----*/


  en_tete(salle->l_monstre);
  ajout_droit(salle->l_monstre,creer_monstre(10,20,1)); /* Création d'un monstre au coordonnées x=10 et y=20 */
  salle->m_salle[10][20] = MONSTRE;

  i=0;
  printf("Test de tire d'un projectile avec un monstre situer à 5 cases :\n");
  tirer_projectile(salle,10,15,0,1,1);
  p = salle->l_projectile->ec->p_val;
  if(salle->l_projectile->nb_elem == 1)
    printf("  Le projectile a été crée aux coordonnées : x = %d  y = %d \n",p->x,p->y);
  else
    printf("  Le projectile n'a pas été crée\n");

  while(!liste_vide(salle->l_projectile)){
    deplacer_projectile(salle,joueur,i);
    i++;
  }
  if(liste_vide(salle->l_monstre))
    printf("  Le projectile et le monstre on bien été supprimé \n");
  printf("\n");


  /*----Test de tire d'un projectile avec un joueur situer à 5 cases----*/


  i=0;
  printf("Test de tire d'un projectile avec un joueur situer à 5 cases :\n");
  tirer_projectile(salle,10,25,0,1,1);
  p = salle->l_projectile->ec->p_val;
  if(salle->l_projectile->nb_elem == 1)
    printf("  Le projectile a été crée aux coordonnées : x = %d  y = %d \n",p->x,p->y);
  else
    printf("  Le projectile n'a pas été crée\n");

  printf("  Nombre de point de vie du joueur : %d \n",joueur->pv);
  while(!liste_vide(salle->l_projectile)){
    deplacer_projectile(salle,joueur,i);
    i++;
  }
  if(i==4){
    printf("  Nombre de point de vie du joueur aprés avoir été touché : %d \n",joueur->pv);
  }

  printf("\n");
  printf("FIN\n");

  free(joueur);
  free(salle->l_monstre->drapeau);
  free(salle->l_projectile->drapeau);
  free(salle->l_monstre);
  free(salle->l_projectile);
  free(salle);

}
