#include "tout.h"

/**
* \file joueur.c
* \author Adrien P. - Paul PDC. - David C. - Paul C.
* \date 04/03/2019
* \brief Permet le mouvement du joueur à travers les salles
*/

int nb_mob_tot;


extern
t_joueur * creer_joueur(int xm, int ym, int xs, int ys, int pv){
    t_joueur * joueur = malloc(sizeof(t_joueur));
    joueur->x_map = xm;
    joueur->y_map = ym;
    joueur->x_salle = M/2;
    joueur->y_salle = N/2;
    joueur->x_mouv = 0;
    joueur->y_mouv = 0;
    joueur->x_direction = 1;
    joueur->y_direction = 0;
    joueur->pv = pv;
    joueur->victoire = 0;
    return joueur;
}


/* Test sur la validité des coordonnées */
extern
int est_franchissable(int x, int y, int salle[M][N]){
	return (salle[x][y] == 0 || salle[x][y] == VIE || salle[x][y] == CLE);
}


extern
void deplacer_joueur(t_salle * m_map[L][L], t_joueur * joueur){
  if(m_map[joueur->x_map][joueur->y_map]->m_salle[joueur->x_salle + joueur->x_direction][joueur->y_salle + joueur->y_direction] == SORTIE && nb_mob_tot == 0 && joueur->cle == 1){
    joueur->victoire = 1;
  }
  else{
    if(est_franchissable( ((joueur->x_salle) + (joueur->x_mouv)) , ((joueur->y_salle) + (joueur->y_mouv)) , m_map[joueur->x_map][joueur->y_map]->m_salle) ){
      m_map[joueur->x_map][joueur->y_map]->m_salle[joueur->x_salle][joueur->y_salle] = 0;
      joueur->x_salle += joueur->x_mouv;
      joueur->y_salle += joueur->y_mouv;
      if(m_map[joueur->x_map][joueur->y_map]->m_salle[joueur->x_salle][joueur->y_salle] == VIE && joueur->pv < 8){
        joueur->pv++;
      }
      if(m_map[joueur->x_map][joueur->y_map]->m_salle[joueur->x_salle][joueur->y_salle] == CLE){
        joueur->cle = 1;
      }
    }
    else {
      if( m_map[joueur->x_map][joueur->y_map]->m_salle[joueur->x_salle + joueur->x_mouv][joueur->y_salle + joueur->y_mouv] == PORTE){
        m_map[joueur->x_map][joueur->y_map]->m_salle[joueur->x_salle][joueur->y_salle] = 0;
        joueur->x_map += joueur->x_mouv;
        joueur->y_map += joueur->y_mouv;
        maj_map(m_map, joueur->x_map, joueur->y_map);
        if(joueur->x_mouv == 1){
          joueur->x_salle = 1;
        }
        if(joueur->x_mouv == -1){
          joueur->x_salle = M - 2;
        }
        if(joueur->y_mouv == 1){
          joueur->y_salle = 1;
        }
        if(joueur->y_mouv == -1){
          joueur->y_salle = N - 2;
        }
      }
    }
    m_map[joueur->x_map][joueur->y_map]->m_salle[joueur->x_salle][joueur->y_salle] = JOUEUR;
  }
}


extern
void controle_joueur(t_joueur * joueur, t_salle * m_map[L][L],SDL_Keycode key){
    switch (key){
      case SDLK_UP : joueur->x_direction = joueur->x_mouv = -1; joueur->y_direction = joueur->y_mouv = 0;
      break;
      case SDLK_DOWN : joueur->x_direction = joueur->x_mouv = 1; joueur->y_direction = joueur->y_mouv = 0;
      break;
      case SDLK_LEFT : joueur->y_direction = joueur->y_mouv = -1; joueur->x_direction = joueur->x_mouv = 0;
      break;
      case SDLK_RIGHT : joueur->y_direction = joueur->y_mouv = 1; joueur->x_direction = joueur->x_mouv = 0;
      break;
      case SDLK_SPACE : tirer_projectile( m_map[joueur->x_map][joueur->y_map], joueur->x_salle, joueur->y_salle, joueur->x_direction, joueur->y_direction, 1 ); flushinp();
      break;
      default: joueur->x_mouv = 0; joueur->y_mouv = 0;
      break;
    }

  deplacer_joueur( m_map, joueur );
}
