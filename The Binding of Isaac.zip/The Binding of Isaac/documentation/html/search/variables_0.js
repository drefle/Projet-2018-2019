var searchData=
[
  ['absi',['absi',['../structs__coord.html#aefe0cc2d4b51e8a3faa34aab1d5b9605',1,'s_coord']]]
];
