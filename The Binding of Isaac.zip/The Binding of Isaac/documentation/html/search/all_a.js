var searchData=
[
  ['ord',['ord',['../structs__coord.html#ae23527fe16e43ff0dd3dbc6aa1ca05c8',1,'s_coord']]]
];
