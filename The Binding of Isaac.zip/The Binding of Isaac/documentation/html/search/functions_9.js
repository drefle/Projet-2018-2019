var searchData=
[
  ['tex_5fimg_5fpng',['tex_img_png',['../fonc__sdl_8c.html#a2ae28f5a6139ce0b82c3b93ed8f012e0',1,'tex_img_png(char *s, SDL_Renderer *renderer):&#160;fonc_sdl.c'],['../tout_8h.html#a40bbe368f33e9801fac3e2eb330f1f16',1,'tex_img_png(char *s, SDL_Renderer *renderer):&#160;fonc_sdl.c']]],
  ['tirer_5fprojectile',['tirer_projectile',['../projectile_8c.html#adeef4d101c73886232af7b645ba4bbb4',1,'tirer_projectile(t_salle *salle, int x, int y, int mouv_x, int mouv_y, int vit):&#160;projectile.c'],['../tout_8h.html#adeef4d101c73886232af7b645ba4bbb4',1,'tirer_projectile(t_salle *salle, int x, int y, int mouv_x, int mouv_y, int vit):&#160;projectile.c']]]
];
