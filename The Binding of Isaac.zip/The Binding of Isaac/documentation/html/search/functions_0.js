var searchData=
[
  ['afficher_5fmat_5fdistance',['afficher_mat_distance',['../salle_8c.html#a22c16f173c65e7bc6996c25a42eb6a48',1,'afficher_mat_distance(int mat_distance[M][N]):&#160;salle.c'],['../tout_8h.html#a22c16f173c65e7bc6996c25a42eb6a48',1,'afficher_mat_distance(int mat_distance[M][N]):&#160;salle.c']]],
  ['afficher_5fsalle',['afficher_salle',['../salle_8c.html#a1e89a37f23aaed6f1674d5dd375f2c4d',1,'afficher_salle(t_salle *m_map[L][L], int mat[M][N], SDL_Renderer *salle_render, t_res *ressource, t_joueur *joueur):&#160;salle.c'],['../tout_8h.html#ac8aae40e37bbbebed8a04839d9a2e57f',1,'afficher_salle(t_salle *m_map[L][L], int mat[M][N], SDL_Renderer *salle_render, t_res *ressource, t_joueur *joueur):&#160;salle.c']]]
];
